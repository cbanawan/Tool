<div class="col-md-8 ">
<a  class="btn btn-success" href="<?php echo base_url('manageUser/addUser');?>">Add User</a>
</div>
<div class="table-responsive">
    <table class="table table-bordered table-hover" id="user_lists">
        <thead>
            <tr>
                <th class="table-checkbox">
                    <input type="checkbox" class="group-checkable" data-set="#user_lists .checkboxes"/>
                </th>                
                <th>Username</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>
        </thead>        
    </table>
</div>
<div class="row">        
    <div class="col-md-12">
    <div class="page-info"></div>                        
    </div>
</div>
