<div class="table-responsive">
    <table class="table table-bordered table-hover" id="project_lists">
        <thead>
            <tr>
                              
                <th style="width:10px;">ID</th>
                <th style="width:245px;">Name</th>
                <th>Date</th>
                <th>Created By</th>
                <th>Status</th>
<!--                <th>IR</th>
                <th>LOI</th>
                <th>CPC</th>
                <th>N Complete</th>
                <th>Target</th>-->
                <th>Actions</th>
            </tr>
        </thead>        
    </table>
</div>
<div class="row">        
    <div class="col-md-12">
    <div class="page-info"></div>                        
    </div>
</div>
<script type="text/javascript">
    var p_cntry = "";
	var p_segment = "";
</script>
