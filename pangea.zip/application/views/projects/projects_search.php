<div>
    <div id="project_search_result">

    </div>
</div>