<div class="btn-group" data-toggle="buttons">
    <label class="btn default active">
        <input type="checkbox" class="toggle"> Option 1 </label>
    <label class="btn default">
        <input type="checkbox" class="toggle"> Option 2 </label>
    <label class="btn default">
        <input type="checkbox" class="toggle"> Option 3 </label>
</div>